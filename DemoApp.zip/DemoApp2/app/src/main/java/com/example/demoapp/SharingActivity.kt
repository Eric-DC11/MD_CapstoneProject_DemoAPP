package com.example.demoapp

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class SharingActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sharing)
    }
}